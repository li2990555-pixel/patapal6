import React, { useState, useEffect, useRef, useCallback } from 'react';
import PataSlime from '../components/PataSlime';
import SendIcon from '../components/icons/SendIcon';
import MicrophoneIcon from '../components/icons/MicrophoneIcon';
import KeyboardIcon from '../components/icons/KeyboardIcon';
import { ChatMessage } from '../types';
import PermissionGuideModal from '../components/PermissionGuideModal';

// Check for browser support for SpeechRecognition API
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
const isSpeechRecognitionSupported = !!SpeechRecognitionAPI;

const ChatBubble: React.FC<{ message: string; from: 'user' | 'pata'; pataBackground: string | null; }> = ({ message, from, pataBackground }) => {
    const isPata = from === 'pata';
    const pataDefaultBg = 'linear-gradient(to bottom right, #818cf8, #a855f7)';
    
    const bubbleStyle = isPata ? { background: pataBackground || pataDefaultBg } : {};

    return (
        <div className={`flex items-end gap-2 ${isPata ? 'justify-start' : 'justify-end'}`}>
            {isPata && (
              <div className="flex-shrink-0">
                 <PataSlime size="xs" background={pataBackground} />
              </div>
            )}
            <div 
                className={`max-w-xs md:max-w-sm px-4 py-2 rounded-2xl shadow-sm ${
                    isPata 
                    ? 'text-white rounded-bl-none' 
                    : 'bg-violet-500 text-white rounded-br-none'
                }`}
                style={bubbleStyle}
            >
                 {message === '...' ? (
                    <div className="flex items-center gap-1.5 py-1">
                        <span className="w-1.5 h-1.5 bg-white/70 rounded-full animate-pulse" style={{animationDelay: '0s'}}></span>
                        <span className="w-1.5 h-1.5 bg-white/70 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></span>
                        <span className="w-1.5 h-1.5 bg-white/70 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></span>
                    </div>
                ) : (
                    <p className="whitespace-pre-wrap">{message}</p>
                )}
            </div>
        </div>
    );
}

interface CompanionScreenProps {
  pataBackground: string | null;
  chatMessages: ChatMessage[];
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  currentUser: string | null;
}

const CompanionScreen: React.FC<CompanionScreenProps> = ({ pataBackground, chatMessages, setChatMessages, currentUser }) => {
    const [chatInput, setChatInput] = useState('');
    const [isPataReplying, setIsPataReplying] = useState(false);
    const [inputMode, setInputMode] = useState<'text' | 'voice'>('text');
    const [isListening, setIsListening] = useState(false);
    const [showPermissionGuide, setShowPermissionGuide] = useState(false);
    
    const recognitionRef = useRef<SpeechRecognition | null>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (chatMessages.length === 0 && currentUser) {
             const welcomeMessage = `哈喽 ${currentUser}！我的主要功能是陪你一起背书哦！不过，如果你想找人聊聊天，或者有什么心事想和我说，我也是一个超棒的倾听者呢。`;
            setChatMessages([{ from: 'pata', message: welcomeMessage }]);
        }
    }, [currentUser, chatMessages.length, setChatMessages]);

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [chatMessages]);

    const handleSendChatMessage = useCallback(async (messageText: string) => {
        if (!messageText.trim() || isPataReplying) return;

        const newUserMessage: ChatMessage = { from: 'user', message: messageText.trim() };
        setIsPataReplying(true);
        setChatInput('');
        setChatMessages(prev => [...prev, newUserMessage, { from: 'pata', message: '...' }]);

        try {
            // The backend needs to handle the history to maintain context.
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: newUserMessage.message,
                    // Sending previous messages for context, excluding the initial welcome.
                    history: chatMessages.length > 1 ? chatMessages.slice(1) : [],
                }),
            });

            if (!response.ok || !response.body) {
                throw new Error(`API request failed with status ${response.status}`);
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let accumulatedText = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                accumulatedText += decoder.decode(value, { stream: true });
                
                setChatMessages(prev => {
                    const newMessages = [...prev];
                    if (newMessages.length > 0 && newMessages[newMessages.length - 1].from === 'pata') {
                        newMessages[newMessages.length - 1] = { from: 'pata', message: accumulatedText };
                    }
                    return newMessages;
                });
            }

        } catch (error) {
            console.error("API proxy error:", error);
            const errorMessage = '哎呀，我好像遇到了一点麻烦，请稍后再试。';
            setChatMessages(prev => {
                const newMessages = [...prev];
                 if (newMessages.length > 0 && newMessages[newMessages.length - 1].from === 'pata') {
                    newMessages[newMessages.length - 1] = { from: 'pata', message: errorMessage };
                }
                return newMessages;
            });
        } finally {
            setIsPataReplying(false);
        }
    }, [isPataReplying, setChatMessages, chatMessages]);
    
    // Setup Speech Recognition
    useEffect(() => {
        if (!isSpeechRecognitionSupported) {
            console.warn("Speech recognition is not supported by this browser.");
            return;
        }

        const recognition = new SpeechRecognitionAPI();
        recognition.continuous = false;
        recognition.lang = 'zh-CN';
        recognition.interimResults = false;

        recognition.onresult = (event) => {
            const transcript = event.results[event.results.length - 1][0].transcript.trim();
            if (transcript) {
                handleSendChatMessage(transcript);
            }
        };

        recognition.onerror = (event) => {
            console.error("Speech recognition error:", event.error);
            if (event.error === 'not-allowed') {
                setShowPermissionGuide(true);
            }
            setIsListening(false);
        };

        recognition.onend = () => {
            setIsListening(false);
        };
        
        recognitionRef.current = recognition;

    }, [handleSendChatMessage]);

    const toggleListening = () => {
        if (!recognitionRef.current || isPataReplying) return;

        if (isListening) {
            recognitionRef.current.stop();
        } else {
            try {
                recognitionRef.current.start();
                setIsListening(true);
            } catch(e) {
                console.error("Could not start recognition:", e);
                // The onerror event should handle this, but as a fallback:
                if (e instanceof DOMException && e.name === 'NotAllowedError') {
                    setShowPermissionGuide(true);
                }
                setIsListening(false);
            }
        }
    };

    return (
    <div className="flex flex-col h-full p-4">
        <div ref={chatContainerRef} className="flex-grow space-y-4 overflow-y-auto pb-4 pr-2">
            <div className="flex justify-center my-4">
                <PataSlime size="md" background={pataBackground}/>
            </div>
             {chatMessages.map((msg, index) => (
                <ChatBubble key={index} from={msg.from} message={msg.message} pataBackground={pataBackground} />
             ))}
        </div>
        <div className="flex-shrink-0 flex items-center gap-2 p-2 bg-white rounded-xl shadow-md">
            {isSpeechRecognitionSupported && (
                 <button
                    onClick={() => setInputMode(prev => prev === 'text' ? 'voice' : 'text')}
                    className="p-2 flex-shrink-0 rounded-full text-slate-500 hover:bg-slate-100 transition-colors"
                    aria-label={inputMode === 'text' ? '切换到语音输入' : '切换到文字输入'}
                >
                    {inputMode === 'text' ? <MicrophoneIcon /> : <KeyboardIcon />}
                </button>
            )}

            <div className="flex-grow">
                 {inputMode === 'text' ? (
                     <input 
                        type="text" 
                        placeholder="和Pata聊聊..." 
                        className="w-full bg-transparent focus:outline-none px-2"
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendChatMessage(chatInput)}
                        disabled={isPataReplying}
                    />
                 ) : (
                    <div className="w-full text-center">
                        <span className={`text-sm ${isListening ? 'text-violet-500 font-medium' : 'text-slate-500'}`}>
                            {isListening ? '正在聆听...' : '请点击右侧麦克风开始说话'}
                        </span>
                    </div>
                 )}
            </div>
            
            {inputMode === 'text' ? (
                <button 
                    className="bg-violet-500 text-white p-2 rounded-lg hover:bg-violet-600 transition disabled:bg-slate-300 disabled:cursor-not-allowed flex-shrink-0"
                    onClick={() => handleSendChatMessage(chatInput)}
                    disabled={isPataReplying || !chatInput.trim()}
                    aria-label="发送消息"
                >
                    <SendIcon />
                </button>
            ) : (
                isSpeechRecognitionSupported && (
                    <button
                        onClick={toggleListening}
                        className={`p-2 rounded-full transition-colors flex-shrink-0 ${isListening ? 'bg-rose-500 text-white animate-pulse' : 'bg-violet-500 text-white'}`}
                        disabled={isPataReplying}
                        aria-label={isListening ? '停止录音' : '开始录音'}
                    >
                        <MicrophoneIcon />
                    </button>
                )
            )}
        </div>

        {showPermissionGuide && (
            <PermissionGuideModal onClose={() => setShowPermissionGuide(false)} pataBackground={pataBackground} />
        )}
    </div>
    )
};

export default CompanionScreen;