import React, { useState, useEffect, useCallback } from 'react';
import { PataDiaryEntry, Task, ChatMessage, UserDiaryEntry } from '../types';
import { MOOD_MAP } from '../constants/moods';


const DiaryEntryCard: React.FC<{ date: string; content: string; emoji: string }> = ({ date, content, emoji }) => (
  <div className="bg-white p-5 rounded-2xl shadow-md transition-transform transform hover:scale-[1.02] hover:shadow-lg animate-fade-in-up">
    <div className="flex items-center justify-between mb-3">
      <span className="font-bold text-slate-700">{date}</span>
      <span className="text-2xl">{emoji}</span>
    </div>
    <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">{content}</p>
  </div>
);

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void }> = ({ label, isActive, onClick }) => (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors duration-200 ${
        isActive ? 'bg-violet-500 text-white shadow' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
      }`}
    >
      {label}
    </button>
);

interface DiaryScreenProps {
    pataDiary: PataDiaryEntry[];
    setPataDiary: React.Dispatch<React.SetStateAction<PataDiaryEntry[]>>;
    userDiary: UserDiaryEntry[];
    setUserDiary: React.Dispatch<React.SetStateAction<UserDiaryEntry[]>>;
    tasks: Task[];
    moodHistory: { [date: string]: string[] };
    chatHistory: { [date: string]: ChatMessage[] };
}

const DiaryScreen: React.FC<DiaryScreenProps> = ({
    pataDiary,
    setPataDiary,
    userDiary,
    setUserDiary,
    tasks,
    moodHistory,
    chatHistory
}) => {
    const [activeTab, setActiveTab] = useState<'pata' | 'user'>('user');
    const [newUserEntry, setNewUserEntry] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    const handleSaveUserEntry = () => {
        if (newUserEntry.trim() === '') return;

        const date = new Date();
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');

        const newEntry: UserDiaryEntry = {
            id: Date.now(),
            date: `${year}-${month}-${day}`,
            content: newUserEntry.trim(),
        };

        setUserDiary([newEntry, ...userDiary]);
        setNewUserEntry('');
    };
    
    const generateMissingEntries = useCallback(async () => {
        setIsGenerating(true);
        const firstLoginDateStr = localStorage.getItem('pata_first_login_date');
        if (!firstLoginDateStr) {
            setIsGenerating(false);
            return;
        }

        let updatedDiary = [...pataDiary];

        if (updatedDiary.length === 0) {
            const birthEntry: PataDiaryEntry = {
                date: firstLoginDateStr,
                content: '我出生啦！从今天起，我就是你的专属伙伴Pata。让我们一起记录生活的点滴，共同成长吧！',
                emoji: '🎉'
            };
            updatedDiary.push(birthEntry);
        }

        const getDateFromString = (dateStr: string) => {
            const [year, month, day] = dateStr.split('-').map(Number);
            return new Date(year, month - 1, day);
        };
        
        const sortedDiary = [...updatedDiary].sort((a, b) => a.date.localeCompare(b.date));
        const lastEntryDate = sortedDiary.length > 0 ? getDateFromString(sortedDiary[sortedDiary.length - 1].date) : getDateFromString(firstLoginDateStr);
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        let currentDate = new Date(lastEntryDate);
        currentDate.setDate(currentDate.getDate() + 1);

        const entriesToGenerate: string[] = [];
        while (currentDate <= today) {
            const dateString = currentDate.toISOString().split('T')[0];
            if (!sortedDiary.some(entry => entry.date === dateString)) {
                entriesToGenerate.push(dateString);
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }

        if (entriesToGenerate.length === 0) {
            setIsGenerating(false);
            if (JSON.stringify(pataDiary) !== JSON.stringify(updatedDiary)) {
                 setPataDiary(updatedDiary);
            }
            return;
        }
        
        const dailyDataForPrompt = entriesToGenerate.map(dateStr => {
            const dailyTasks = tasks.filter(t => (t.deadline === dateStr || new Date(t.id).toISOString().split('T')[0] === dateStr));
            const dailyMoods = moodHistory[dateStr] || [];
            const dailyChats = chatHistory[dateStr] || [];
            const isActive = dailyTasks.length > 0 || dailyMoods.length > 0 || dailyChats.length > 1;

            if (isActive) {
                const moodTitles = dailyMoods.map(id => MOOD_MAP[id]?.title).filter(Boolean).join(', ');
                const completedTasks = dailyTasks.filter(t => t.completed).map(t => t.text);
                const chatSummary = dailyChats.length > 2 ? `我们聊了${dailyChats.length}条消息。` : '我们简单聊了聊。';
                return {
                    date: dateStr,
                    type: 'active',
                    tasks: completedTasks.length > 0 ? completedTasks.join('、') : '没有记录',
                    moods: moodTitles || '没有记录',
                    chats: dailyChats.length > 1 ? chatSummary : '今天没有聊天'
                };
            } else {
                return {
                    date: dateStr,
                    type: 'inactive'
                };
            }
        });

        const prompt = `你叫Pata，是一个温暖、治愈系的AI伙伴。请从你的视角，为你的用户批量生成日记。
日记的语言风格必须是亲近的、温暖的、充满鼓励和安慰的。
下面是一个包含多天情况的数组，请为其中每一天生成一篇日记。

数据:
${JSON.stringify(dailyDataForPrompt, null, 2)}

对于 'active' 类型，请根据当天发生的事件（任务、心情、聊天）自然地组织日记内容，并融入你的感想和对用户的鼓励。
对于 'inactive' 类型，表示用户今天没有来看你，请写一篇表达思念但又积极乐观的日记，可以给用户一些温馨建议或描述你自己做了什么。

请以一个JSON数组的格式返回所有日记。数组中的每个对象都应包含 "date" (YYYY-MM-DD格式), "content" (日记正文), 和 "emoji" (一个最能代表当天心情的表情符号)。`;
        
        try {
            const response = await fetch('/api/generate-diary', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt }),
            });
    
            if (!response.ok) {
                throw new Error(`API request failed with status ${response.status}`);
            }
            
            const newEntries: PataDiaryEntry[] = await response.json();
            
            if (Array.isArray(newEntries)) {
                 const finalDiary = [...updatedDiary, ...newEntries];
                 setPataDiary(finalDiary);
            }
        } catch (error) {
            console.error(`Failed to batch generate diaries via proxy:`, error);
        } finally {
            setIsGenerating(false);
        }

    }, [pataDiary, setPataDiary, tasks, moodHistory, chatHistory]);

    useEffect(() => {
        if (activeTab === 'pata') {
            generateMissingEntries();
        }
    }, [activeTab, generateMissingEntries]);


    return (
        <div className="p-4 flex flex-col h-full">
            <div className="text-center mt-6 mb-4">
                <h1 className="text-2xl font-bold text-slate-800">心情日记</h1>
                <p className="text-slate-500">记录着我们共同成长的点点滴滴。</p>
            </div>

            <div className="flex justify-center gap-3 mb-6">
                <TabButton label="我的碎碎念" isActive={activeTab === 'user'} onClick={() => setActiveTab('user')} />
                <TabButton label="Pata的日记" isActive={activeTab === 'pata'} onClick={() => setActiveTab('pata')} />
            </div>

            <div className="flex-grow space-y-4 overflow-y-auto pb-4 pr-2">
                {activeTab === 'pata' && (
                    <>
                        {isGenerating && (
                            <div className="text-center py-10 text-slate-500">
                                <p>Pata正在奋笔疾书中...</p>
                            </div>
                        )}
                        {pataDiary.length > 0 ? (
                            [...pataDiary].sort((a, b) => b.date.localeCompare(a.date)).map((entry, index) => (
                                <div key={entry.date} style={{ animationDelay: `${index * 50}ms` }}>
                                    <DiaryEntryCard {...entry} />
                                </div>
                            ))
                        ) : !isGenerating && (
                           <div className="text-center py-10">
                                <p className="text-slate-500">这里是Pata为你写日记的地方。</p>
                            </div>
                        )}
                    </>
                )}
                
                {activeTab === 'user' && (
                    <div className="flex flex-col h-full animate-fade-in-up">
                        <div className="bg-white p-4 rounded-2xl shadow-md mb-4 flex-shrink-0">
                            <textarea
                                value={newUserEntry}
                                onChange={(e) => setNewUserEntry(e.target.value)}
                                placeholder="今天有什么想说的吗？"
                                className="w-full h-24 p-2 bg-slate-100 text-slate-800 border-transparent rounded-xl focus:ring-2 focus:ring-violet-400 focus:outline-none transition resize-none"
                            />
                            <div className="flex justify-end mt-3">
                                <button
                                    onClick={handleSaveUserEntry}
                                    disabled={!newUserEntry.trim()}
                                    className="px-5 py-2 bg-violet-500 text-white font-bold rounded-xl hover:bg-violet-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
                                >
                                    保存碎碎念
                                </button>
                            </div>
                        </div>

                        <div className="space-y-4">
                            {userDiary.length > 0 ? (
                                userDiary.map((entry) => (
                                    <div key={entry.id}>
                                        <DiaryEntryCard date={entry.date} content={entry.content} emoji="💭" />
                                    </div>
                                ))
                            ) : (
                                <div className="text-center py-10">
                                    <p className="text-slate-500">还没有任何记录哦，快写下第一条吧！</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default DiaryScreen;