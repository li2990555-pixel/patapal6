export enum Screen {
  LOGIN = 'LOGIN',
  DAILY_RECORD = 'DAILY_RECORD',
  MOOD_RECORD = 'MOOD_RECORD',
  PET_NURTURING = 'PET_NURTURING',
  COMPANION = 'COMPANION',
  DIARY = 'DIARY',
}

export enum Priority {
  URGENT_IMPORTANT = 'URGENT_IMPORTANT', // 重要紧急
  IMPORTANT_NOT_URGENT = 'IMPORTANT_NOT_URGENT', // 重要不紧急
  URGENT_NOT_IMPORTANT = 'URGENT_NOT_IMPORTANT', // 不重要紧急
  NOT_IMPORTANT_NOT_URGENT = 'NOT_IMPORTANT_NOT_URGENT', // 不重要不紧急
}

export interface Task {
  id: number;
  text: string;
  completed: boolean;
  priority: Priority;
  deadline?: string;
  flowDuration?: number; // in seconds
  moodId?: string;
  pauseCount?: number;
}

export interface Mood {
  id: string;
  title: string;
  color: string;
  gradient: string;
  fromColor: string;
  toColor: string;
}

export interface PataDiaryEntry {
  date: string;
  content: string;
  emoji: string;
}

export interface UserDiaryEntry {
  id: number;
  date: string;
  content: string;
}

export interface ChatMessage {
  from: 'user' | 'pata';
  message: string;
}

// Web Speech API for TypeScript
// These are simplified interfaces to satisfy the compiler for browser-specific APIs.
declare global {
    interface SpeechRecognition {
        continuous: boolean;
        lang: string;
        interimResults: boolean;
        onend: () => void;
        onerror: (event: any) => void;
        onresult: (event: any) => void;
        start: () => void;
        stop: () => void;
    }

    interface Window {
        SpeechRecognition: new () => SpeechRecognition;
        webkitSpeechRecognition: new () => SpeechRecognition;
    }
}