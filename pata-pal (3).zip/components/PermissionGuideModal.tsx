
import React from 'react';
import PataSlime from './PataSlime';

interface PermissionGuideModalProps {
  onClose: () => void;
  pataBackground: string | null;
}

const PermissionGuideModal: React.FC<PermissionGuideModalProps> = ({ onClose, pataBackground }) => {
  return (
    <div 
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in" 
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-sm text-center animate-fade-in-up" 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-center mb-4">
          <PataSlime size="sm" background={pataBackground} />
        </div>
        
        <h2 className="text-xl font-bold text-slate-800 mb-2">哎呀，听不到你的声音...</h2>
        <p className="text-slate-500 mb-6">好像是麦克风权限没有打开哦。请按照下面的步骤，为Pata打开麦克风权限吧！</p>
        
        <div className="text-left space-y-3 bg-slate-50 p-4 rounded-lg border border-slate-200">
            <p><strong className="font-semibold text-violet-600">第1步:</strong> 打开手机的 <strong className="font-semibold">「设置」</strong> 应用。</p>
            <p><strong className="font-semibold text-violet-600">第2步:</strong> 向下滚动，找到并点击我们的应用 <strong className="font-semibold">「Pata Pal」</strong>。</p>
            <p><strong className="font-semibold text-violet-600">第3步:</strong> 在应用设置中，找到 <strong className="font-semibold">「麦克风」</strong> 选项。</p>
            <p><strong className="font-semibold text-violet-600">第4步:</strong> 打开旁边的开关以<strong className="font-semibold">允许</strong>访问。</p>
        </div>

        <p className="text-xs text-slate-400 mt-4">完成后，回到这里再试一次吧！</p>

        <button
          onClick={onClose}
          className="w-full mt-6 py-3 bg-violet-500 text-white font-bold rounded-xl hover:bg-violet-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-violet-500 transition-transform transform hover:scale-105"
        >
          我知道啦
        </button>
      </div>
    </div>
  );
};

export default PermissionGuideModal;
