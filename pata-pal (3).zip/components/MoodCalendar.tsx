// This component is no longer in use.
// Calendar functionality has been merged into PetNurturingScreen.
