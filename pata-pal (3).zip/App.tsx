
import React, { useState, useCallback, useEffect } from 'react';
import LoginScreen from './screens/LoginScreen';
import DailyRecordScreen from './screens/DailyRecordScreen';
import MoodRecordScreen from './screens/MoodRecordScreen';
import PetNurturingScreen from './screens/PetNurturingScreen';
import CompanionScreen from './screens/CompanionScreen';
import DiaryScreen from './screens/DiaryScreen';
import BottomNavBar from './components/BottomNavBar';
import FloatingPata from './components/FloatingPata';
import SettingsIcon from './components/icons/SettingsIcon';
import SettingsModal from './components/SettingsModal';
import { Screen, Task, PataDiaryEntry, ChatMessage, UserDiaryEntry } from './types';
import { MOOD_MAP } from './constants/moods';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.LOGIN);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [taskForMoodLogging, setTaskForMoodLogging] = useState<{ id: number; text: string } | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [moodHistory, setMoodHistory] = useState<{ [date: string]: string[] }>({});
  const [pataBackground, setPataBackground] = useState<string | null>(null);
  const [memoryPataBackground, setMemoryPataBackground] = useState<string | null>(null);
  const [pataDiary, setPataDiary] = useState<PataDiaryEntry[]>([]);
  const [userDiary, setUserDiary] = useState<UserDiaryEntry[]>([]);
  const [chatHistory, setChatHistory] = useState<{ [date: string]: ChatMessage[] }>({});
  const [loginData, setLoginData] = useState({ consecutiveDays: 0, totalDays: 0 });
  const [floatingPataMessage, setFloatingPataMessage] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    const savedCreds = localStorage.getItem('pata_credentials');
    if (savedCreds) {
      try {
        const { username } = JSON.parse(savedCreds);
        if (username) {
          handleLogin(username, true);
        }
      } catch (error) {
        console.error("Failed to parse credentials, clearing them.", error);
        localStorage.removeItem('pata_credentials');
      }
    }
  }, []);

  useEffect(() => {
    try {
        const savedMoods = localStorage.getItem('pata_mood_history');
        if (savedMoods) {
            const parsedMoods = JSON.parse(savedMoods);
            Object.keys(parsedMoods).forEach(key => {
                if(typeof parsedMoods[key] === 'string') {
                    parsedMoods[key] = [parsedMoods[key]];
                }
            });
            setMoodHistory(parsedMoods);
        }
        const savedTasks = localStorage.getItem('pata_tasks');
        if (savedTasks) {
            setTasks(JSON.parse(savedTasks));
        }

        const savedMemoryItem = localStorage.getItem('pata_memory');
        const today = new Date().toISOString().split('T')[0];

        if (savedMemoryItem) {
            const savedMemory = JSON.parse(savedMemoryItem);
            if (savedMemory && typeof savedMemory.date === 'string' && savedMemory.date === today) {
                setMemoryPataBackground(savedMemory.background);
            } else {
                setMemoryPataBackground(null);
            }
        } else {
            if (localStorage.getItem('pata_memory_background')) {
                localStorage.removeItem('pata_memory_background');
            }
            setMemoryPataBackground(null);
        }
        
        const savedPataDiary = localStorage.getItem('pata_diary_entries');
        if (savedPataDiary) {
            setPataDiary(JSON.parse(savedPataDiary));
        }

        const savedUserDiary = localStorage.getItem('pata_user_diary');
        if (savedUserDiary) {
            setUserDiary(JSON.parse(savedUserDiary));
        }
        
        const savedChatHistory = localStorage.getItem('pata_chat_history');
        if (savedChatHistory) {
            setChatHistory(JSON.parse(savedChatHistory));
        }
        
        const savedLoginData = localStorage.getItem('pata_login_data');
        if (savedLoginData) {
            const data = JSON.parse(savedLoginData);
            setLoginData({ consecutiveDays: data.consecutiveDays, totalDays: data.totalDays });
        }


    } catch (error) {
        console.error("Failed to load data from localStorage", error);
        setMemoryPataBackground(null); // Reset on error
    }
  }, []);
  
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const todaysMoodIds = moodHistory[today] || [];
    
    let newBackground: string | null = null;

    if (todaysMoodIds.length === 1) {
      const mood = MOOD_MAP[todaysMoodIds[0]];
      if (mood) {
        newBackground = `linear-gradient(to bottom right, ${mood.fromColor}, ${mood.toColor})`;
      }
    } else if (todaysMoodIds.length > 1) {
      const colors = todaysMoodIds
        .map(id => MOOD_MAP[id]?.toColor)
        .filter(Boolean);
      if (colors.length > 0) {
        newBackground = `linear-gradient(to bottom right, ${colors.join(', ')})`;
      }
    }
    
    setPataBackground(newBackground);
  }, [moodHistory]);

  useEffect(() => {
      localStorage.setItem('pata_mood_history', JSON.stringify(moodHistory));
  }, [moodHistory]);
  
  useEffect(() => {
      localStorage.setItem('pata_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
      localStorage.setItem('pata_diary_entries', JSON.stringify(pataDiary));
  }, [pataDiary]);

  useEffect(() => {
    localStorage.setItem('pata_user_diary', JSON.stringify(userDiary));
  }, [userDiary]);

  useEffect(() => {
    localStorage.setItem('pata_chat_history', JSON.stringify(chatHistory));
  }, [chatHistory]);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const memoryToSave = {
        background: pataBackground,
        date: today,
    };
    localStorage.setItem('pata_memory', JSON.stringify(memoryToSave));
    setMemoryPataBackground(pataBackground);
  }, [pataBackground]);


  const handleLogin = useCallback((username: string, isAutoLogin = false) => {
    if (!isAutoLogin) {
      const firstLoginDate = localStorage.getItem('pata_first_login_date');
      if (!firstLoginDate) {
        localStorage.setItem('pata_first_login_date', new Date().toISOString().split('T')[0]);
      }
      
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];

      const savedLoginData = localStorage.getItem('pata_login_data');
      let data = savedLoginData ? JSON.parse(savedLoginData) : { consecutiveDays: 0, totalDays: 0, lastLogin: '' };

      if (data.lastLogin !== todayStr) {
          const yesterday = new Date(today);
          yesterday.setDate(today.getDate() - 1);
          const yesterdayStr = yesterday.toISOString().split('T')[0];

          if (data.lastLogin === yesterdayStr) {
              data.consecutiveDays += 1;
          } else {
              data.consecutiveDays = 1;
          }
          data.totalDays += 1;
          data.lastLogin = todayStr;
          
          localStorage.setItem('pata_login_data', JSON.stringify(data));
          setLoginData({ consecutiveDays: data.consecutiveDays, totalDays: data.totalDays });
      }
    }
    
    setIsAuthenticated(true);
    setCurrentUser(username);
    setCurrentScreen(Screen.DAILY_RECORD);
  }, []);

  const handleFlowSessionFinish = useCallback((task: { id: number; text: string }) => {
    setTaskForMoodLogging(task);
    setCurrentScreen(Screen.MOOD_RECORD);
  }, []);

  const handleMoodSaved = useCallback((moodId: string) => {
    if (taskForMoodLogging) {
        setTasks(prevTasks =>
            prevTasks.map(task =>
                task.id === taskForMoodLogging.id
                    ? { ...task, moodId: moodId, completed: true }
                    : task
            )
        );
    }
    const today = new Date().toISOString().split('T')[0];
    setMoodHistory(prevHistory => {
        const todaysMoods = prevHistory[today] || [];
        return {
            ...prevHistory,
            [today]: [...todaysMoods, moodId]
        };
    });
    
    setTaskForMoodLogging(null);
    setCurrentScreen(Screen.DAILY_RECORD);
  }, [taskForMoodLogging, setTasks]);
  
  const updateTodayChat = useCallback((newMessages: React.SetStateAction<ChatMessage[]>) => {
    const today = new Date().toISOString().split('T')[0];
    setChatHistory(prev => {
        const currentMessages = prev[today] || [];
        const updatedMessages = typeof newMessages === 'function' ? newMessages(currentMessages) : newMessages;
        return {...prev, [today]: updatedMessages};
    });
  }, []);

  const handleClearCache = useCallback(() => {
    if (window.confirm('你确定要清除所有本地数据吗？此操作不可逆，将清除所有任务、日记和成长记录。')) {
        Object.keys(localStorage).forEach(key => {
            if (key.startsWith('pata_')) {
                localStorage.removeItem(key);
            }
        });
        window.location.reload();
    }
  }, []);

  const renderScreen = () => {
    if (!isAuthenticated) {
      return <LoginScreen onLogin={handleLogin} pataBackground={memoryPataBackground} />;
    }

    const today = new Date().toISOString().split('T')[0];

    switch (currentScreen) {
      case Screen.DAILY_RECORD:
        return (
          <DailyRecordScreen 
            tasks={tasks}
            setTasks={setTasks}
            onFlowFinish={handleFlowSessionFinish} 
            pataBackground={pataBackground}
          />
        );
      case Screen.MOOD_RECORD:
        return <MoodRecordScreen completedTask={taskForMoodLogging} onMoodSaved={handleMoodSaved} pataBackground={pataBackground} />;
      case Screen.PET_NURTURING:
        return <PetNurturingScreen
                  moodHistory={moodHistory}
                  tasks={tasks}
                  userDiary={userDiary}
                  loginData={loginData}
                  pataBackground={pataBackground}
                  setFloatingPataMessage={setFloatingPataMessage}
                />;
      case Screen.COMPANION:
        const todayChat = chatHistory[today] || [];
        return <CompanionScreen 
                    pataBackground={pataBackground} 
                    chatMessages={todayChat}
                    setChatMessages={updateTodayChat}
                    currentUser={currentUser}
                />;
      case Screen.DIARY:
        return <DiaryScreen 
                    pataDiary={pataDiary}
                    setPataDiary={setPataDiary}
                    userDiary={userDiary}
                    setUserDiary={setUserDiary}
                    tasks={tasks}
                    moodHistory={moodHistory}
                    chatHistory={chatHistory}
                />;
      default:
         return (
          <DailyRecordScreen 
            tasks={tasks}
            setTasks={setTasks}
            onFlowFinish={handleFlowSessionFinish} 
            pataBackground={pataBackground}
          />
        );
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800">
      <div className="max-w-md mx-auto h-screen flex flex-col relative">
        {isAuthenticated && (
            <button
                onClick={() => setIsSettingsOpen(true)}
                className="absolute top-4 right-4 z-40 p-2 text-slate-500 hover:text-violet-500 transition-colors"
                aria-label="打开设置"
            >
                <SettingsIcon />
            </button>
        )}
        <main className="flex-grow relative overflow-y-auto pb-20">
          {renderScreen()}
        </main>
        {isAuthenticated && (
          <>
            <BottomNavBar
              currentScreen={currentScreen}
              setCurrentScreen={setCurrentScreen}
            />
            <FloatingPata
              pataBackground={pataBackground}
              message={floatingPataMessage}
              setMessage={setFloatingPataMessage}
            />
          </>
        )}
        {isSettingsOpen && (
            <SettingsModal
                onClose={() => setIsSettingsOpen(false)}
                onClearCache={handleClearCache}
            />
        )}
      </div>
    </div>
  );
};

export default App;
