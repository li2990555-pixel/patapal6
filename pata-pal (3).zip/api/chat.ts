// api/chat.ts
import { GoogleGenAI } from '@google/genai';

// Tell Vercel to use the Edge Runtime for best streaming performance
export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  // Only accept POST requests
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: { 'Content-Type': 'application/json' } });
  }

  try {
    // Parse the message and history from the request body
    const { message, history } = await req.json();

    // Securely get the API key from environment variables
    if (!process.env.API_KEY) {
        return new Response(JSON.stringify({ error: 'API key not configured' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // The system instruction defines the persona of the AI.
    const systemInstruction = "你是Pata，一个温暖、治愈、充满鼓励的AI伙伴。你的主要功能是陪用户背书，但你也是一个很好的倾听者。请用亲切、可爱的语气和用户交流。";

    // Map the chat history and the new message to the format expected by the SDK
    const contents = [
      ...(history || []).map((msg: { from: string, message:string }) => ({
        role: msg.from === 'user' ? 'user' : 'model',
        parts: [{ text: msg.message }]
      })),
      {
        role: 'user',
        parts: [{ text: message }]
      }
    ];

    // Call the Gemini API using the SDK's streaming method
    const stream = await ai.models.generateContentStream({
      model: 'gemini-2.5-flash',
      contents,
      config: {
        systemInstruction: systemInstruction,
      },
    });

    // Create a new stream to pipe the response from Gemini to the client
    const responseStream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        for await (const chunk of stream) {
          // Send each text chunk back to the client as it arrives
          controller.enqueue(encoder.encode(chunk.text));
        }
        controller.close();
      }
    });

    return new Response(responseStream, {
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });

  } catch (error) {
    console.error('API Proxy Error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}