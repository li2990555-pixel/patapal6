// api/generate-diary.ts
import { GoogleGenAI } from '@google/genai';
import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only accept POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Parse the prompt from the request body
    const { prompt } = req.body;

    // Securely get the API key from environment variables
    if (!process.env.API_KEY) {
        return res.status(500).json({ error: 'API key not configured' });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Call the Gemini API and request a JSON response
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        },
    });

    const generatedText = response.text;
    
    if (!generatedText) {
        console.error('Invalid response structure from Gemini API:', response);
        return res.status(500).json({ error: 'Invalid response structure from Gemini API' });
    }
    
    // The response text is a JSON string, so we parse it before sending it back
    try {
        const finalJson = JSON.parse(generatedText);
        return res.status(200).json(finalJson);
    } catch (parseError) {
        console.error('Failed to parse generated text as JSON:', generatedText);
        return res.status(500).json({ error: 'Gemini did not return valid JSON', details: generatedText });
    }

  } catch (error) {
    console.error('API Proxy Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}